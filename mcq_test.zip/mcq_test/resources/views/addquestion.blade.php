<html>

<head>
    <title>Add New Question</title>
</head>

<body>
   
    <div>
    <h1> Add New Questions</h1>
        <form action="" method="POST">
            @csrf
            <input type="radio" name="section" value="1" />Technical
            <br>
            <input type="radio" name="section" value="2" />Aptitude
            <br>
            <input type="radio" name="section" value="3" />Logical
            <br>
            <h3>Enter question. </h3>
            <textarea name="question" rows="5" cols="50" wrap="soft"></textarea>
            <h3>Enter the options </h3>
            <strong>1.</strong><input type="text" name="a" placeholder="Enter option"><br><br>
            <strong>2.</strong><input type="text" name="b" placeholder="Enter option"><br><br>
            <strong>3.</strong><input type="text" name="c" placeholder="Enter option"><br><br>
            <strong>4.</strong><input type="text" name="d" placeholder="Enter option"><br><br>
            <h3>Enter the Correct Answers </h3><br>
            <strong>Ans.</strong><input type="text" name="ans" placeholder="Enter Answer"><br><br>

            <button type="submit">Add Question</button>
        </form>
    </div>
</body>

</html>