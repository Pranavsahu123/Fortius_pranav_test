<h1>Question List</h1>

<h3>Technical Question</h3>
<table border=1>
    <tr>
        <td>SR No.</td>
        <td>Question</td>
        <td>Choose currect option</td>
        <td>Operation</td>
    </tr>
    @php
    $i = 1;
    @endphp
    @foreach($questions as $question)
    @if($question->section == 1)
    <tr>
        <td>{{$i}}</td>
        <td> {{$question->question}}</td>
        <td><input type="radio" name="ans" value={{$question->a}} />{{$question->a}} <input type="radio" name="ans"
                value={{$question->b}} />{{$question->b}} <input type="radio" name="ans"
                value={{$question->c}} />{{$question->c}} <input type="radio" name="ans"
                value={{$question->d}} />{{$question->d}}</td>
        <td><a href={{"delete/".$question['id']}}>Delete</a>
            <a href={{"edit/".$question['id']}}>Edit</a>
        </td>
    </tr>
    @endif
    @php
    $i++;
    @endphp
    @endforeach
</table>

<h3>Aptitude Question</h3>
<table border=1>
    <tr>
        <td>SR No.</td>
        <td>Question</td>
        <td>Choose currect option</td>
        <td>Operation</td>
    </tr>
    @php
    $i = 1;
    @endphp
    @foreach($questions as $question)
    @if($question->section == 2)
    <tr>
        <td>{{$i}}</td>
        <td> {{$question->question}}</td>
        <td><input type="radio" name="ans" value={{$question->a}} />{{$question->a}} <input type="radio" name="ans"
                value={{$question->b}} />{{$question->b}} <input type="radio" name="ans"
                value={{$question->c}} />{{$question->c}} <input type="radio" name="ans"
                value={{$question->d}} />{{$question->d}}</td>
        <td><a href={{"delete/".$question['id']}}>Delete</a>
            <a href={{"edit/".$question['id']}}>Edit</a>
        </td>
    </tr>
    @endif
    @php
    $i++;
    @endphp
    @endforeach
</table>

<h3>Logical Question</h3>
<table border=1>
    <tr>
        <td>SR No.</td>
        <td>Question</td>
        <td>Choose currect option</td>
        <td>Operation</td>
    </tr>
    @php
    $i = 1;
    @endphp
    @foreach($questions as $question)
    @if($question->section == 3)
    <tr>
        <td>{{$i}}</td>
        <td> {{$question->question}}</td>
        <td><input type="radio" name="ans" value={{$question->a}} />{{$question->a}} <input type="radio" name="ans"
                value={{$question->b}} />{{$question->b}} <input type="radio" name="ans"
                value={{$question->c}} />{{$question->c}} <input type="radio" name="ans"
                value={{$question->d}} />{{$question->d}}</td>
        <td><a href={{"delete/".$question['id']}}>Delete</a>
            <a href={{"edit/".$question['id']}}>Edit</a>
        </td>
    </tr>
    @endif
    @php
    $i++;
    @endphp
    @endforeach
</table>
<div>
</div>