<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\QuestionController;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});


Route::get('list',[QuestionController::class,'list']);

Route::view('add','addquestion');
Route::post('add',[QuestionController::class,'addQuestion']);

Route::get('edit/{id}',[QuestionController::class,'showData']);
Route::post('edit',[QuestionController::class,'update']);

Route::get('delete/{id}',[QuestionController::class,'delete']);



?>