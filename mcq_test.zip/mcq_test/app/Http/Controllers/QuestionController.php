<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Models\question;

class QuestionController extends Controller
{

    function list()
    {
        $data = question::all();
        
        return view('list', ['questions' => $data]);
    }


    function addQuestion(Request $req)
    {
        
        $req->validate([
            "question" => "required",
            "a" => "required",
            "b" => "required",
            "c" => "required",
            "d" => "required",
            "ans" => "required",
            "section" => "required",
        ]);
        $ques = new question;
        $ques->question = $req->question;
        $ques->a = $req->a;
        $ques->b = $req->b;
        $ques->c = $req->c;
        $ques->d = $req->d;
        $ques->ans = $req->ans;
        $ques->section = $req->section;
        $ques->save();
        return redirect('add');
    }


    function showData($id)
    {
        $data = question::find($id);
        // print_r($data);
        // exit;
        return view('edit', ['data' => $data]);
    }

    function update(Request $req)
    {
        $req->validate([
            "question" => "required",
            "a" => "required",
            "b" => "required",
            "c" => "required",
            "d" => "required",
            "ans" => "required",
            "section" => "required",
        ]);
        $data = question::find($req->id);
        $data->question = $req->question;
        $data->a = $req->a;
        $data->b = $req->b;
        $data->c = $req->c;
        $data->d = $req->d;
        $data->ans = $req->ans;
        $data->section = $req->section;
        $data->save();
        return redirect('list');
    }

    function delete($id)
    {
        $data = question::find($id);
        $data->delete();
        return redirect('list');
    }

}
